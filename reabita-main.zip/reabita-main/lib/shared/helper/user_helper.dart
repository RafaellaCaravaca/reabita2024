import 'package:firebase_auth/firebase_auth.dart' as auth;
import '../../entities/user.dart';

class UserHelper {
  static User? _user;

  static set currentUser(User user) {
    _user = user;
  }

  static User get currentUser => _user!;

  static Future<void> logout() async {
    await auth.FirebaseAuth.instance.signOut();
  }
}
