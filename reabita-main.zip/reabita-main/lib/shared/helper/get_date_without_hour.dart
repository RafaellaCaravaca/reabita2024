DateTime getDateWithoutHour(DateTime date) =>
    DateTime(date.year, date.month, date.day);