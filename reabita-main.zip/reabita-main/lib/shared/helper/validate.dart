String? isRequired(String? v) =>
    v?.isEmpty == true ? 'Esse campo é obrigatorio' : null;

Function(String? v) minWidth(int size) => (String? v) =>
    (v?.length ?? 0) < size ? 'Esse exige pelo menos $size caracteres' : null;

String? validateEmail(String? value) {
  RegExp regex =
      RegExp(r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
          r'{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]'
          r'{0,253}[a-zA-Z0-9])?)*$');
  if (value == null || !regex.hasMatch(value)) {
    return 'Digite um e-mail válido';
  } else {
    return null;
  }
}

String? mergeValidate(List<Function(String?)> validators, String? v) {
  for (int i = 0; i < validators.length; i++) {
    final error = validators[i](v);
    if (error != null) return error;
  }
}
