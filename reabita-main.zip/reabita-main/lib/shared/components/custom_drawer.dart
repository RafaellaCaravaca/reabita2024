import 'package:flutter/material.dart';
import '../../modules/login/login_page.dart';
import '../helper/user_helper.dart';

class CustomDrawer extends StatefulWidget {
  const CustomDrawer({Key? key}) : super(key: key);

  @override
  _CustomDrawerState createState() => _CustomDrawerState();
}

class _CustomDrawerState extends State<CustomDrawer> {
  Future<void> logout() async {
    await UserHelper.logout();
    Navigator.pushNamedAndRemoveUntil(
        context, LoginPage.route, ModalRoute.withName('/root'));
  }

  @override
  Widget build(BuildContext context) => Drawer(
          child: ListView(children: [
        DrawerHeader(
            decoration: BoxDecoration(color: Theme.of(context).primaryColor),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  CircleAvatar(
                      radius: 32,
                      child:
                          Text(UserHelper.currentUser.name[0].toUpperCase())),
                  Text(UserHelper.currentUser.name,
                      style: TextStyle(color: Colors.white)),
                  Text(UserHelper.currentUser.email,
                      style: TextStyle(color: Colors.white)),
                ])),
        ListTile(title: Text('Home')),
        ListTile(title: Text('Sair'), onTap: logout),
      ]));
}
