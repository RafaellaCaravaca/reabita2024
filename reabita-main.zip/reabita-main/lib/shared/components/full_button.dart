import 'package:flutter/material.dart';
import 'circular_progress_indicator_white.dart';

class FullButton extends StatelessWidget {
  final Function() onPressed;
  final String label;
  final bool isLoading;

  const FullButton(
      {Key? key,
      required this.onPressed,
      required this.label,
      this.isLoading = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) => SizedBox(
      width: double.infinity,
      height: 42,
      child: ElevatedButton(
          onPressed: onPressed,
          child: isLoading ? CircularProgressIndicatorWhite() : Text(label)));
}
