import 'package:flutter/material.dart';

class DropdownFieldItem {
  final dynamic value;
  final String label;

  DropdownFieldItem({
    required this.value,
    required this.label,
  });
}

class DropdownField extends StatelessWidget {
  const DropdownField({
    Key? key,
    required this.label,
    required this.value,
    required this.list,
    required this.onChange,
  }) : super(key: key);

  final String label;
  final dynamic value;
  final List<DropdownFieldItem> list;
  final Function(dynamic value) onChange;

  @override
  Widget build(BuildContext context) => DropdownButtonFormField(
      decoration: InputDecoration(filled: true, labelText: label),
      value: value,
      icon: const Icon(Icons.keyboard_arrow_down),
      isExpanded: true,
      itemHeight: 48,
      iconSize: 24,
      elevation: 16,
      onChanged: onChange,
      items: list
          .map((e) => DropdownMenuItem(child: Text(e.label), value: e.value))
          .toList());
}
