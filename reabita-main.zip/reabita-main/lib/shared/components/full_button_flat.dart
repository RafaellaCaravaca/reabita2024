import 'package:flutter/material.dart';
import 'circular_progress_indicator_white.dart';

class FullButtonFlat extends StatelessWidget {
  final Function() onPressed;
  final String label;
  final bool isLoading;

  const FullButtonFlat(
      {Key? key,
      required this.onPressed,
      required this.label,
      this.isLoading = false})
      : super(key: key);

  @override
  Widget build(BuildContext context) => SizedBox(
      width: double.infinity,
      height: 42,
      child: OutlinedButton(
          onPressed: onPressed,
          child: isLoading ? CircularProgressIndicatorWhite() : Text(label)));
}
