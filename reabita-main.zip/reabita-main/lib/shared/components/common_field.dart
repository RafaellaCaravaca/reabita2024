import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CommonField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final Widget? suffixIcon;
  final bool obscureText;
  final TextInputType? keyboardType;
  final List<TextInputFormatter>? inputFormatters;
  final FormFieldValidator<String>? validator;

  CommonField({
    Key? key,
    required this.controller,
    required this.label,
    this.suffixIcon,
    this.keyboardType,
    this.obscureText = false,
    this.inputFormatters,
    this.validator,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => TextFormField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      inputFormatters: inputFormatters,
      validator: validator,
      decoration: InputDecoration(
          filled: true, labelText: label, suffixIcon: suffixIcon));
}
