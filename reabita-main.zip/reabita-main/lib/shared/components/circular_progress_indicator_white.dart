import 'package:flutter/material.dart';

class CircularProgressIndicatorWhite extends StatelessWidget {
  const CircularProgressIndicatorWhite({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => CircularProgressIndicator(
      valueColor: AlwaysStoppedAnimation<Color>(Colors.white));
}