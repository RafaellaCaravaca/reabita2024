import 'package:flutter/material.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'common_field.dart';

class BirthdataeField extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final FormFieldValidator<String>? validator;

  const BirthdataeField({
    Key? key,
    required this.controller,
    required this.label,
    this.validator,
  }) : super(key: key);

  @override
  _BirthdataeFieldState createState() => _BirthdataeFieldState();
}

class _BirthdataeFieldState extends State<BirthdataeField> {
  var maskFormatter = MaskTextInputFormatter(
      mask: '##/##/####', filter: {'#': RegExp(r'[0-9]')});

  @override
  Widget build(BuildContext context) => CommonField(
        controller: widget.controller,
        label: widget.label,
        inputFormatters: [maskFormatter],
        validator: widget.validator,
      );
}
