import 'package:flutter/material.dart';

import '../../entities/workout.dart';
import '../../modules/workout_detail/workout_detail_page.dart';

class CardWorkout extends StatelessWidget {
  final Workout workout;

  const CardWorkout({required this.workout, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) => InkWell(
      onTap: () => Navigator.of(context)
          .pushNamed(WorkoutDetailPage.route, arguments: workout),
      child: Card(
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.center, children: [
        Expanded(
            child: Container(
                decoration: BoxDecoration(
                    image: DecorationImage(
                        image: NetworkImage(workout.image),
                        fit: BoxFit.cover)))),
        Padding(
            padding: const EdgeInsets.all(8.0),
            child:
                Text(workout.name, style: Theme.of(context).textTheme.caption))
      ])));
}
