import 'package:flutter/material.dart';

import '../../entities/exercise.dart';
import '../../modules/exercise_detail/exercise_detail_page.dart';

class CardExercise extends StatelessWidget {
  final int index;
  final Exercise exercise;

  const CardExercise({
    required this.index,
    required this.exercise,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: () => Navigator.of(context)
            .pushNamed(ExerciseDetailPage.route, arguments: exercise),
        child: Row(children: [
          Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('${(index + 1)}º',
                  style: TextStyle(
                      fontSize: 24, color: Theme.of(context).primaryColor))),
          Expanded(
              child: Card(
                  elevation: 2,
                  child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(children: [
                        SizedBox(
                            height: 70,
                            width: 100,
                            child: Container(
                                color: Colors.grey.shade200,
                                child: Image.network(exercise.thumb))),
                        Padding(
                            padding: const EdgeInsets.only(left: 8.0),
                            child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width - 190,
                                    child: Text(exercise.name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                        )),
                                  ),
                                  SizedBox(height: 4),
                                  SizedBox(
                                      width: MediaQuery.of(context).size.width -
                                          190,
                                      child: Text(
                                        'Quantidade: ${exercise.quantity}',
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                      )),
                                  SizedBox(
                                    width:
                                        MediaQuery.of(context).size.width - 190,
                                    child: Text(
                                      'Intervalo entre séries: ${exercise.interval} min',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  )
                                ]))
                      ]))))
        ]),
      );
}
