class NoInternetConnectionException implements Exception {}
