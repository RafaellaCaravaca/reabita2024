class UnauthorizedException implements Exception {}
