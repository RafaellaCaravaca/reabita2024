import 'package:flutter/material.dart';

import '../../data/user_repository.dart';
import '../../shared/components/common_field.dart';
import '../../shared/components/custom_snackbar.dart';
import '../../shared/components/full_button.dart';
import '../../shared/components/full_button_flat.dart';
import '../../shared/components/password_field.dart';
import '../../shared/exceptions/exceptions.dart';
import '../../shared/helper/user_helper.dart';
import '../home/home_page.dart';
import '../register/register_page.dart';

class LoginPage extends StatefulWidget {
  static String route = '/login';
  final UserRepository userRepository;

  const LoginPage({required this.userRepository, Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = TextEditingController();
  final _pass = TextEditingController();
  bool _isLoading = false;

  Future<void> loginWithEmail() async {
    try {
      setState(() {
        _isLoading = true;
      });

      final userId = await widget.userRepository.login(_email.text, _pass.text);

      final user = await widget.userRepository.selectUser(userId);
      UserHelper.currentUser = user;
      setState(() {
        _isLoading = false;
      });
      Navigator.of(context).pushReplacementNamed(HomePage.route);
    } on UnauthorizedException {
      setState(() {
        _isLoading = false;
      });
      CustomSnackbar.show(context, 'Usuario e/ou senha inválidos');
    }
  }

  void goToRegister() => Navigator.of(context).pushNamed(RegisterPage.route);

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(),
      body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(children: [
            CommonField(
                controller: _email,
                label: 'E-mail',
                keyboardType: TextInputType.emailAddress),
            SizedBox(height: 16),
            PasswordField(controller: _pass, label: 'Senha'),
            SizedBox(height: 16),
            FullButtonFlat(
              label: 'CADASTRE-SE',
              onPressed: goToRegister,
            ),
            SizedBox(height: 8),
            FullButton(
              label: 'ENTRAR',
              onPressed: loginWithEmail,
              isLoading: _isLoading,
            ),
          ])));
}
