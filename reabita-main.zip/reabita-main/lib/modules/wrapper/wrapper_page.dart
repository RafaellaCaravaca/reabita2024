import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../../data/user_repository.dart';
import '../../shared/helper/user_helper.dart';
import '../home/home_page.dart';
import '../login/login_page.dart';

class WrapperPage extends StatefulWidget {
  final UserRepository userRepository;

  const WrapperPage({required this.userRepository, Key? key}) : super(key: key);

  @override
  _WrapperPageState createState() => _WrapperPageState();
}

class _WrapperPageState extends State<WrapperPage> {
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance!.addPostFrameCallback((_) {
      getUser();
    });
  }

  void getUser() async {
    final id = FirebaseAuth.instance.currentUser?.uid;
    if (id != null) {
      final user = await widget.userRepository.selectUser(id);
      UserHelper.currentUser = user;
      Navigator.pushReplacementNamed(context, HomePage.route);
    } else {
      Navigator.pushReplacementNamed(context, LoginPage.route);
    }
  }

  @override
  Widget build(BuildContext context) =>
      Center(child: CircularProgressIndicator());
}
