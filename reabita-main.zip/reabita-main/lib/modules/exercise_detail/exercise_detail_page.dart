import 'package:flutter/material.dart';

import '../../data/exercises_repository.dart';
import '../../entities/exercise.dart';

class ExerciseDetailPage extends StatefulWidget {
  static const String route = '/exercise_detail';
  final Exercise exercise;
  final ExerciseRepository exerciseRepository;

  const ExerciseDetailPage({
    required this.exercise,
    required this.exerciseRepository,
    Key? key,
  }) : super(key: key);

  @override
  _ExerciseDetailPageState createState() => _ExerciseDetailPageState();
}

class _ExerciseDetailPageState extends State<ExerciseDetailPage> {
  bool isLoading = true;
  List<Exercise> exercises = [];


  @override
  void initState() {
    super.initState();
  }

  Widget buildText(String title, String value) =>
      RichText(
          text: TextSpan(
              text: title,
              style:
                  TextStyle(color: Colors.black87, fontWeight: FontWeight.w600),
              children: [
            TextSpan(text: value, style: TextStyle(fontWeight: FontWeight.w400))
          ]));

  Widget buildQuantityText(String value) =>
      buildText('Quantidade de repetições: ', value);

  Widget buildIntervalText(String value) =>
      buildText('Intervalo: ', '$value min');

  @override
  Widget build(BuildContext context) => Scaffold(
      appBar: AppBar(title: Text(widget.exercise.name)),
      body: SingleChildScrollView(
          padding: const EdgeInsets.all(8),
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Center(
              child: ClipOval(
                  child: Container(
                    color: Colors.grey.shade200,
                    child: Image.network(
                      widget.exercise.thumb,
                      fit: BoxFit.contain,
                      width: MediaQuery.of(context).size.width * .6,
                      height: MediaQuery.of(context).size.width * .6,
                    ),
                  )),
            ),
            Text(widget.exercise.description, maxLines: 10),
            SizedBox(height: 16),
            buildQuantityText(widget.exercise.quantity),
            SizedBox(height: 4),
            buildIntervalText(widget.exercise.interval.toString()),
            SizedBox(height: 16),
          ])));
}
