import 'package:flutter/material.dart';

import '../../data/exercises_repository.dart';
import '../../data/favorites_repository.dart';
import '../../data/training_history_repository.dart';
import '../../entities/exercise.dart';
import '../../entities/workout.dart';
import '../../shared/components/card_exercise.dart';

class WorkoutDetailPage extends StatefulWidget {
  static const String route = '/workout_detail';
  final Workout workout;
  final ExerciseRepository exerciseRepository;
  final FavoritesRepository favoritesRepository;
  final TrainingHistoryRepository trainingHistoryRepository;

  const WorkoutDetailPage({
    required this.workout,
    required this.exerciseRepository,
    required this.favoritesRepository,
    required this.trainingHistoryRepository,
    Key? key,
  }) : super(key: key);

  @override
  _WorkoutDetailPageState createState() => _WorkoutDetailPageState();
}

class _WorkoutDetailPageState extends State<WorkoutDetailPage> {
  bool isLoading = true;
  bool isFavorite = false;
  List<Exercise> exercises = [];
  bool isSavingMarkAsDone = false;

  @override
  void initState() {
    super.initState();
    search();
  }

  Future<void> search() async {
    setState(() {
      isLoading = true;
    });
    final list = await widget.exerciseRepository.search(widget.workout);
    setState(() {
      exercises = list;
      isLoading = false;
    });
    final _isFavorite =
        await widget.favoritesRepository.isFavorite(widget.workout);
    setState(() {
      isFavorite = _isFavorite;
    });
  }

  Future<void> favorite(Workout workout) async {
    final _isFavorite = await widget.favoritesRepository.favorite(workout);
    setState(() {
      isFavorite = _isFavorite;
    });
  }

  Future<void> markAsDone() async {
    setState(() {
      isSavingMarkAsDone = true;
    });
    try {
      await widget.trainingHistoryRepository.markAsDone(widget.workout);
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Treino registrado com sucesso')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Tivemos um problema, tente novamente mais tarde')));
    } finally {
      setState(() {
        isSavingMarkAsDone = false;
      });
    }
  }

  Widget buildText(String title, String value) =>
      RichText(
          text: TextSpan(
              text: title,
              style:
                  TextStyle(color: Colors.black87, fontWeight: FontWeight.w600),
              children: [
            TextSpan(text: value, style: TextStyle(fontWeight: FontWeight.w400))
          ]));

  Widget buildDurationText(String value) =>
      buildText('Duração estimada: ', '$value min');

  Widget buildLevelText(String value) => buildText('Nivel: ', value);

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: Text(widget.workout.name),
          actions: [
            IconButton(
                onPressed: () => favorite(widget.workout),
                icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border))
          ],
        ),
        body: Builder(builder: (context) {
          if (isLoading) return Center(child: CircularProgressIndicator());
          return SingleChildScrollView(
              padding: const EdgeInsets.all(8),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    buildDurationText(widget.workout.duration.toString()),
                    SizedBox(height: 4),
                    buildLevelText(widget.workout.level),
                    SizedBox(height: 16),
                    ...exercises
                        .asMap()
                        .entries
                        .map((exercise) => CardExercise(
                            exercise: exercise.value, index: exercise.key))
                        .toList()
                  ]));
        }),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: isSavingMarkAsDone ? null : markAsDone,
          label: Text('Registrar treino'),
        ),
      );
}
