import 'package:flutter/material.dart';

import '../../data/user_repository.dart';
import '../../entities/user.dart';
import '../../shared/components/birthdate_field.dart';
import '../../shared/components/common_field.dart';
import '../../shared/components/custom_snackbar.dart';
import '../../shared/components/dropdown_field.dart';
import '../../shared/components/full_button.dart';
import '../../shared/components/password_field.dart';
import '../../shared/components/weigth_field.dart';
import '../../shared/helper/validate.dart';
import '../login/login_page.dart';

class RegisterPage extends StatefulWidget {
  static String route = '/register';
  final UserRepository userRepository;

  const RegisterPage({
    Key? key,
    required this.userRepository,
  }) : super(key: key);

  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _formKey = GlobalKey<FormState>();
  final _email = TextEditingController();
  final _pass = TextEditingController();
  final _name = TextEditingController();
  final _birthdate = TextEditingController();
  String _gender = 'M';
  final _height = TextEditingController();
  final _weight = TextEditingController();
  String _activityLevel = 'I';
  bool _isSaving = false;

  void updateGender(curGender) {
    setState(() {
      _gender = curGender;
    });
  }

  void updateActivityLevel(curActivityLevel) {
    setState(() {
      _activityLevel = curActivityLevel;
    });
  }

  void updateIsSaving(bool isSaving) {
    setState(() {
      _isSaving = isSaving;
    });
  }

  Future<void> submit() async {
    if (_formKey.currentState!.validate()) {
      updateIsSaving(true);
      try {
        await widget.userRepository.createUser(User(
          email: _email.text,
          pass: _pass.text,
          name: _name.text,
          gender: userGenderfromKey(_gender),
          activityLevel: userActivityLevelFromKey(_activityLevel),
          birthdate: birthdateToDateTime(_birthdate.text),
          weight: _weight.text,
        ));
        Navigator.of(context).pushReplacementNamed(LoginPage.route);
      } catch (e) {
        CustomSnackbar.show(
            context, 'Tivemos um problema, tente novamente mais tarde');
      } finally {
        updateIsSaving(false);
      }
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                CommonField(
                  controller: _email,
                  label: 'E-mail',
                  validator: (v) =>
                      mergeValidate([isRequired, validateEmail], v),
                ),
                SizedBox(height: 8),
                PasswordField(
                  controller: _pass,
                  label: 'Senha',
                  validator: (v) => mergeValidate([
                    isRequired,
                    minWidth(6),
                  ], v),
                ),
                SizedBox(height: 8),
                CommonField(
                  controller: _name,
                  label: 'Nome',
                  validator: isRequired,
                ),
                SizedBox(height: 8),
                BirthdataeField(
                  controller: _birthdate,
                  label: 'Data de nascimento',
                  validator: isRequired,
                ),
                SizedBox(height: 8),
                DropdownField(
                    label: 'Sexo',
                    value: _gender,
                    list: [
                      DropdownFieldItem(value: 'M', label: 'Masculino'),
                      DropdownFieldItem(value: 'F', label: 'Feminino'),
                    ],
                    onChange: updateGender),
                SizedBox(height: 8),
                DropdownField(
                    label: 'Qual seu nível de atividade fisica?',
                    value: _activityLevel,
                    list: [
                      DropdownFieldItem(value: 'I', label: 'Baixo'),
                      DropdownFieldItem(value: 'II', label: 'Moderado'),
                      DropdownFieldItem(value: 'III', label: 'Alto'),
                    ],
                    onChange: updateActivityLevel),
                SizedBox(height: 8),
                WeightField(
                  controller: _weight,
                  label: 'Altura',
                  validator: isRequired,
                ),
                SizedBox(height: 8),
                CommonField(
                  controller: _height,
                  label: 'Peso',
                  suffixIcon: SizedBox(
                      height: 48, width: 48, child: Center(child: Text('Kg'))),
                  validator: isRequired,
                ),
                SizedBox(height: 8),
                FullButton(
                    onPressed: submit,
                    label: 'CRIAR USUARIO',
                    isLoading: _isSaving)
              ],
            ),
          ),
        ),
      );
}
