import 'package:flutter/material.dart';
import '../../data/training_history_repository.dart';

import '../../entities/training_history.dart';
import '../../shared/helper/get_date_without_hour.dart';
import 'calendar_widget.dart';
import 'training_history_of_day.dart';

class CalendarPage extends StatefulWidget {
  CalendarPage({
    required this.trainingHistoryRepository,
  });

  final TrainingHistoryRepository trainingHistoryRepository;

  @override
  State<CalendarPage> createState() => _CalendarPageState();
}

class _CalendarPageState extends State<CalendarPage> {
  List<TrainingHistory> trainingHistory = [];
  List<TrainingHistory> trainingHistoryOfDay = [];
  DateTime selectedDate = DateTime.now();

  @override
  Widget build(BuildContext context) => SingleChildScrollView(
          child: Column(
        children: [
          CalendarWidget(
            dateSelected: selectedDate,
            onSelect: (DateTime dateTime) {
              setState(() {
                selectedDate = dateTime;
                trainingHistoryOfDay = trainingHistory
                    .where((element) =>
                        getDateWithoutHour(element.date) ==
                        getDateWithoutHour(dateTime))
                    .toList();
              });
            },
            search: (date) async {
              final startDate = DateTime(date.year, date.month, 1);
              final endDate = DateTime(date.year, date.month + 1, 0);
              final items = await widget.trainingHistoryRepository
                  .search(startDate, endDate);
              setState(() {
                trainingHistory = items;
                selectedDate = DateTime.now();
                trainingHistoryOfDay = trainingHistory
                    .where((element) =>
                getDateWithoutHour(element.date) ==
                    getDateWithoutHour(selectedDate))
                    .toList();
              });
            },
            trainingHistory: trainingHistory,
          ),
          ListTile(title: Text('Exercicios', textAlign: TextAlign.center)),
          trainingHistoryOfDay.isEmpty
              ? ListTile(title: Text('Nenhum exercicio'))
              : TrainingHistoryOfDay(trainingHistoryOfDay: trainingHistoryOfDay)
        ],
      ));
}
