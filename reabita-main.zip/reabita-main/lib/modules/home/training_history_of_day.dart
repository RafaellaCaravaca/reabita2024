import 'package:flutter/material.dart';
import '../../entities/training_history.dart';

class TrainingHistoryOfDay extends StatelessWidget {
  final List<TrainingHistory> trainingHistoryOfDay;

  TrainingHistoryOfDay({
    required this.trainingHistoryOfDay,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) => Column(
      children: trainingHistoryOfDay
          .map((e) => ListTile(
              leading: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(e.duration.toString(),
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    Text('min')
                  ]),
              title: Text(e.name)))
          .toList());
}
