import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';

import '../../data/favorites_repository.dart';
import '../../data/training_history_repository.dart';
import '../../data/workout_repository.dart';
import '../../entities/workout.dart';
import '../../shared/components/card_workout.dart';
import '../../shared/components/custom_drawer.dart';
import 'calendar_page.dart';

class HomePage extends StatefulWidget {
  final WorkoutRepository workoutRepository;
  final FavoritesRepository favoritesRepository;
  final TrainingHistoryRepository trainingHistoryRepository;
  static String route = '/home';

  const HomePage({
    required this.workoutRepository,
    required this.favoritesRepository,
    required this.trainingHistoryRepository,
    Key? key,
  }) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Workout> workouts = [];
  List<Workout> favorites = [];

  Future<void> searchCollection() async {
    final list = await widget.workoutRepository.searchCollection();
    setState(() {
      workouts = list;

    });
  }

  Future<void> searchFavorites() async {
    final list = await widget.favoritesRepository.search();
    await Future.delayed(Duration(milliseconds: 480)); // FIX BUG TRANSITION
    setState(() {
      favorites = list;
    });
  }

  Future<void> saveFavorite(Workout workout, bool value) async {
    final list = await widget.favoritesRepository.search();
    setState(() {
      favorites = list;
    });
  }

  Widget buildGrid(List<Workout> list) => list.isEmpty
      ? Center(child: Text('Nenhum treino foi encontrado'))
      : GridView.count(
          crossAxisCount: 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          childAspectRatio: .9,
          padding: const EdgeInsets.all(8),
          children: list
              .map((e) => CardWorkout(key: Key(e.id), workout: e))
              .toList());


  @override
  void initState() {
    super.initState();
    searchCollection();
  }

  @override
  Widget build(BuildContext context) => DefaultTabController(
      length: 3,
      child: Scaffold(
          appBar: AppBar(
            title: Text('Home'),
            bottom: TabBar(
              labelColor: Colors.black87,
              indicatorColor: Colors.orange,
              onTap: (value) {
                if (value == 1) searchFavorites();
              },
              tabs: const [
                Tab(text: 'Treinos'),
                Tab(text: 'Treinos salvos'),
                Tab(text: 'Histórico'),
              ],
            ),
          ),
          drawer: CustomDrawer(),
          body: TabBarView(children: [
            buildGrid(workouts),
            buildGrid(favorites),
            CalendarPage(
                trainingHistoryRepository: widget.trainingHistoryRepository)
          ])));
}
