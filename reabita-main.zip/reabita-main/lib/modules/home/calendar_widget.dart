import 'package:flutter/material.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../entities/training_history.dart';
import '../../shared/helper/get_date_without_hour.dart';

class CalendarWidget extends StatelessWidget {
  CalendarWidget({
    required this.search,
    required this.dateSelected,
    required this.onSelect,
    required this.trainingHistory,
    Key? key,
  }) : super(key: key);

  final Function(DateTime dateTime) search;
  final List<TrainingHistory> trainingHistory;
  final DateTime dateSelected;
  final Function(DateTime dateTime) onSelect;
  final now = DateTime.now();

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: TableCalendar(
          locale: 'pt_BR',
          headerVisible: false,
          onCalendarCreated: (_) => search(DateTime.now()),
          onPageChanged: (date) async {
            await search(date);
            await onSelect(date);
          },
          eventLoader: (date) => trainingHistory
              .where((element) =>
                  getDateWithoutHour(element.date) == getDateWithoutHour(date))
              .toList(),
          onDaySelected: (date, _) => onSelect(date),
          firstDay: DateTime.utc(now.year - 2, 1, 1),
          lastDay: DateTime.utc(now.year + 2, 1, 1),
          focusedDay: dateSelected,
          currentDay: dateSelected,
        ),
      );
}
