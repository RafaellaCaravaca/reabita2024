import 'package:cloud_firestore/cloud_firestore.dart' as cloud;
import 'package:firebase_auth/firebase_auth.dart' as auth;

import '../entities/user.dart';
import '../shared/exceptions/exceptions.dart';

class UserRepository {
  Future<String> login(String email, String pass) async {
    try {
      auth.UserCredential userCredential = await auth.FirebaseAuth.instance
          .signInWithEmailAndPassword(email: email, password: pass);
      return userCredential.user!.uid;
    } on auth.FirebaseAuthException {
      throw UnauthorizedException();
    } catch (e) {
      rethrow;
    }
  }

  Future<User> selectUser(String id) async {
    cloud.CollectionReference collectionReference =
        cloud.FirebaseFirestore.instance.collection('users');
    final users = await collectionReference.where('id', isEqualTo: id).get();
    if (users.size == 0) {
      throw Exception('Não encontrado');
    }
    return User.fromJSON(
        users.docs.first.data() as Map<String, dynamic>, users.docs.first.id);
  }

  Future<void> createUser(User user) async {
      auth.UserCredential userCredential = await auth.FirebaseAuth.instance
          .createUserWithEmailAndPassword(
              email: user.email, password: user.pass!);

      final newUser = user.copyWith(id: userCredential.user!.uid);

      cloud.CollectionReference collectionReference =
          cloud.FirebaseFirestore.instance.collection('users');

      await collectionReference.add(newUser.toJSON());
  }
}
