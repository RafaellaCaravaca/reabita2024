import 'package:cloud_firestore/cloud_firestore.dart';

import '../entities/exercise.dart';
import '../entities/workout.dart';

class ExerciseRepository {
  Future<List<Exercise>> search(Workout workout) async {
    final reference = await FirebaseFirestore.instance
        .collection('workout')
        .doc(workout.id)
        .get();
    final collectionReference = await FirebaseFirestore.instance
        .collection('exercise')
        .where('idWorkout', isEqualTo: reference.reference)
        .get();
    final docs = collectionReference.docs;
    return docs.map((e) => Exercise.fromJSON(e.data(), e.id)).toList();
  }
}
