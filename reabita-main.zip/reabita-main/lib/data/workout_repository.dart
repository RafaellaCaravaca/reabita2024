import 'package:cloud_firestore/cloud_firestore.dart';

import '../entities/user.dart';
import '../entities/workout.dart';
import '../shared/helper/user_helper.dart';

class WorkoutRepository {
  Future<List<Workout>> searchCollection() async {
    final collectionReference = await FirebaseFirestore.instance
        .collection('workout')
        .orderBy('type')
    //where('type', arrayContains: UserHelper.currentUser.activityLevel.toKey)
        .get();
    final docs = collectionReference.docs;
    return docs.map((e) => Workout.fromJSON(e.data(), e.id)).toList();
  }
}
