import 'package:cloud_firestore/cloud_firestore.dart';

import '../entities/training_history.dart';
import '../entities/workout.dart';
import '../shared/helper/get_date_without_hour.dart';
import '../shared/helper/user_helper.dart';

class TrainingHistoryRepository {
  Future<List<TrainingHistory>> search(
      DateTime startDate, DateTime endDate) async {
    final referenceUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(UserHelper.currentUser.documentId)
        .get();
    final referenceTrainingHistory = await FirebaseFirestore.instance
        .collection('training_history')
        .where('idUser', isEqualTo: referenceUser.reference)
        .where('date', isGreaterThanOrEqualTo: getDateWithoutHour(startDate))
        .where('date',
            isLessThanOrEqualTo: getDateWithoutHour(endDate)
              ..add(Duration(hours: 23, minutes: 59, seconds: 59)))
        .get();
    final docs = referenceTrainingHistory.docs.map((e) => e.data());

    if (docs.isEmpty) return [];

    return referenceTrainingHistory.docs
        .map((e) => TrainingHistory.fromJSON(e.data(), e.id))
        .toList();
  }

  Future<void> markAsDone(Workout workout) async {
    final referenceUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(UserHelper.currentUser.documentId)
        .get();

    await FirebaseFirestore.instance.collection('training_history').add({
      'idUser': referenceUser.reference,
      'duration': workout.duration,
      'name': workout.name,
      'date': Timestamp.now(),
    });
  }
}
