import 'package:cloud_firestore/cloud_firestore.dart';

import '../entities/workout.dart';
import '../shared/helper/user_helper.dart';

class FavoritesRepository {
  Future<List<Workout>> search() async {
    final referenceUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(UserHelper.currentUser.documentId)
        .get();
    final referenceFavorite = await FirebaseFirestore.instance
        .collection('favorites')
        .where('idUser', isEqualTo: referenceUser.reference)
        .get();
    final docs = referenceFavorite.docs.map((e) => e.data());

    if (docs.isEmpty) return [];

    final referenceWorkout = await FirebaseFirestore.instance
        .collection('workout')
        .where(FieldPath.documentId,
            whereIn: docs.map((e) => e['idWorkout']).toList())
        .get();
    return referenceWorkout.docs
        .map((e) => Workout.fromJSON(e.data(), e.id))
        .toList();
  }

  Future<bool> isFavorite(Workout workout) async {
    final referenceUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(UserHelper.currentUser.documentId)
        .get();

    final referenceWorkout = await FirebaseFirestore.instance
        .collection('workout')
        .doc(workout.id)
        .get();

    final favorite = await FirebaseFirestore.instance
        .collection('favorites')
        .where('idWorkout', isEqualTo: referenceWorkout.reference)
        .where('idUser', isEqualTo: referenceUser.reference)
        .get();

    return favorite.size > 0;
  }

  Future<bool> favorite(Workout workout) async {
    final referenceWorkout = await FirebaseFirestore.instance
        .collection('workout')
        .doc(workout.id)
        .get();

    final referenceUser = await FirebaseFirestore.instance
        .collection('users')
        .doc(UserHelper.currentUser.documentId)
        .get();

    final favorite = await FirebaseFirestore.instance
        .collection('favorites')
        .where('idWorkout', isEqualTo: referenceWorkout.reference)
        .where('idUser', isEqualTo: referenceUser.reference)
        .get();

    if (favorite.size > 0) {
      await FirebaseFirestore.instance
          .collection('favorites')
          .doc(favorite.docs.first.id)
          .delete();
      return false;
    } else {
      await FirebaseFirestore.instance.collection('favorites').add({
        'idUser': referenceUser.reference,
        'idWorkout': referenceWorkout.reference
      });
      return true;
    }
  }
}
