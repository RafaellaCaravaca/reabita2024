import 'package:flutter/material.dart';

final kTheme = ThemeData(
    primarySwatch: Colors.orange,
    appBarTheme: AppBarTheme(
        color: Colors.transparent,
        elevation: 0,
        titleTextStyle: TextStyle(color: Colors.black87, fontSize: 20),
        iconTheme: IconThemeData(
          color: Colors.black87,
        ),
        actionsIconTheme: IconThemeData(
          color: Colors.black87,
        ),
      toolbarTextStyle: TextStyle(color: Colors.black87, fontSize: 20),

    ),
    textTheme: TextTheme(
        caption: TextStyle(
            color: Colors.black87, fontSize: 14, fontWeight: FontWeight.w600)));
