import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:page_transition/page_transition.dart';

import 'data/exercises_repository.dart';
import 'data/favorites_repository.dart';
import 'data/training_history_repository.dart';
import 'data/user_repository.dart';
import 'data/workout_repository.dart';
import 'entities/exercise.dart';
import 'entities/workout.dart';
import 'modules/exercise_detail/exercise_detail_page.dart';
import 'modules/home/home_page.dart';
import 'modules/login/login_page.dart';
import 'modules/register/register_page.dart';
import 'modules/workout_detail/workout_detail_page.dart';
import 'modules/wrapper/wrapper_page.dart';
import 'theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  initializeDateFormatting().then((_) => runApp(MyApp()));
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Reabita',
        theme: kTheme,
        home: WrapperPage(userRepository: UserRepository()),
        onGenerateRoute: (settings) {
          switch (settings.name) {
            case '/login':
              return PageTransition(
                  child: LoginPage(
                    userRepository: UserRepository(),
                  ),
                  type: PageTransitionType.fade);
            case '/register':
              return PageTransition(
                  child: RegisterPage(
                    userRepository: UserRepository(),
                  ),
                  type: PageTransitionType.fade);
            case '/home':
              return PageTransition(
                  child: HomePage(
                    workoutRepository: WorkoutRepository(),
                    favoritesRepository: FavoritesRepository(),
                    trainingHistoryRepository: TrainingHistoryRepository(),
                  ),
                  type: PageTransitionType.fade);
            case WorkoutDetailPage.route:
              return PageTransition(
                  child: WorkoutDetailPage(
                    workout: settings.arguments as Workout,
                    exerciseRepository: ExerciseRepository(),
                    favoritesRepository: FavoritesRepository(),
                    trainingHistoryRepository: TrainingHistoryRepository(),
                  ),
                  type: PageTransitionType.bottomToTop);
            case ExerciseDetailPage.route:
              return PageTransition(
                  child: ExerciseDetailPage(
                    exercise: settings.arguments as Exercise,
                    exerciseRepository: ExerciseRepository(),
                  ),
                  type: PageTransitionType.bottomToTop);

            default:
              return null;
          }
        },
      );
}
