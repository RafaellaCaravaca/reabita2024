import 'package:cloud_firestore/cloud_firestore.dart';

class Exercise {
  final String id;
  final String idWorkout;
  final String name;
  final String description;
  final String thumb;
  final String video;
  final String interval;
  final String quantity;

  Exercise({
    required this.id,
    required this.idWorkout,
    required this.name,
    required this.description,
    required this.thumb,
    required this.video,
    required this.interval,
    required this.quantity,
  });

  factory Exercise.fromJSON(Map<String, dynamic> json, String id) => Exercise(
        id: id,
        idWorkout: (json['idWorkout'] as DocumentReference).id,
        name: json['name'],
        description: json['description'],
        thumb: json['thumb'],
        video: json['video'],
        interval: json['interval'],
        quantity: json['quantity'],
      );
}
