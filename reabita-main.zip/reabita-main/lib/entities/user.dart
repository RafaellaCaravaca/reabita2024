enum UserGender {
  M,
  F,
}

extension UserGenderString on UserGender {
  String get toKey => toString().split('.').last;
}

UserGender userGenderfromKey(String key) =>
    UserGender.values.firstWhere((e) => e.toKey == key);

enum UserActivityLevel {
  I,
  // ignore: constant_identifier_names
  II,
  // ignore: constant_identifier_names
  III,
}

extension UserActivityLevelString on UserActivityLevel {
  String get toKey => toString().split('.').last;
}

UserActivityLevel userActivityLevelFromKey(String key) =>
    UserActivityLevel.values.firstWhere((e) => e.toKey == key);

DateTime birthdateToDateTime(String birthdate) {
  final list = birthdate.split('/');
  return DateTime(int.parse(list[2]), int.parse(list[1]), int.parse(list[0]));
}

class User {
  final String? id;
  final String? documentId;
  final UserActivityLevel activityLevel;
  final DateTime birthdate;
  final String email;
  final UserGender gender;

  // final String image;
  final String name;

  // final String type;
  final String weight;
  final String? pass;

  User({
    this.id,
    this.documentId,
    required this.activityLevel,
    required this.email,
    required this.birthdate,
    required this.gender,
    // required this.image,
    required this.name,
    // required this.type,
    required this.weight,
    this.pass,
  });

  factory User.fromJSON(Map<String, dynamic> json, String documentId) => User(
      id: json['id'],
      documentId: documentId,
      activityLevel: userActivityLevelFromKey(json['activityLevel']),
      email: json['email'],
      birthdate: DateTime.parse(json['birthdate']),
      gender: userGenderfromKey(json['gender']),
      name: json['name'],
      weight: json['weight']);

  User copyWith({
    String? id,
    String? documentId,
    UserActivityLevel? activityLevel,
    DateTime? birthdate,
    String? email,
    UserGender? gender,
    String? image,
    String? name,
    String? type,
    String? weight,
    String? pass,
  }) =>
      User(
        id: id ?? this.id,
        documentId: documentId ?? this.documentId,
        activityLevel: activityLevel ?? this.activityLevel,
        birthdate: birthdate ?? this.birthdate,
        email: email ?? this.email,
        gender: gender ?? this.gender,
        // image: image ?? this.image,
        name: name ?? this.name,
        // type: type ?? this.type,
        weight: weight ?? this.weight,
        pass: pass ?? this.pass,
      );

  Map<String, dynamic> toJSON() => {
        'id': id,
        'activityLevel': activityLevel.toKey,
        'birthdate': birthdate.toIso8601String(),
        'email': email,
        'gender': gender.toKey,
        'name': name,
        'weight': weight,
        'pass': pass,
      };
}
