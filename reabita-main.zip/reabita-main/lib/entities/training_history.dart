import 'package:cloud_firestore/cloud_firestore.dart';

class TrainingHistory {
  final String id;
  final String name;
  final String duration;
  final DateTime date;

  TrainingHistory({
    required this.id,
    required this.name,
    required this.duration,
    required this.date,
  });

  factory TrainingHistory.fromJSON(Map<String, dynamic> json, String id) =>
      TrainingHistory(
          id: id,
          name: json['name'],
          duration: json['duration'].toString(),
          date: (json['date'] as Timestamp).toDate());
}
