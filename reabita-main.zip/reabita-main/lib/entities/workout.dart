class Workout {
  final String id;
  final String image;
  final String name;
  final String type;
  final String duration;
  final String level;

  Workout({
    required this.id,
    required this.image,
    required this.name,
    required this.type,
    required this.duration,
    required this.level,
  });

  factory Workout.fromJSON(Map<String, dynamic> json, String id) => Workout(
      id: id,
      image: json['image'],
      name: json['name'],
      type: json['type'].toString(),
      duration: json['duration'],
      level: json['level'],
    );
}
