const firebase = require('firebase-admin');
const fs = require('fs');
const parse = require('csv-parse/lib/sync');


const serviceAccount = require('./key.json');

const readFiles = async () => {
    const workoutsFile = fs.readFileSync('./Cadastro de exercicios Reabita - Treinos.csv').toString();
    const exercisesFile = fs.readFileSync('./Cadastro de exercicios Reabita - Exercicios.csv').toString();
    const workouts = parse(workoutsFile, {columns: true});
    const exercises = parse(exercisesFile, {columns: true});

    const allItems = workouts.map((workout) => ({
        ...workout,
        exercises: exercises.filter((exercise) => exercise.workout === workout.name)
    }))
    // console.log(allItems)
    // console.log(exercises)

    firebase.initializeApp({
        credential: firebase.credential.cert(serviceAccount)
    });

    const db = firebase.firestore();

    db.settings({
        ignoreUndefinedProperties: true,
    });

    for (let i = 0; i < allItems.length; i++) {
        await insertWorkout(db, allItems[i]);
    }
}

const insertWorkout = async (db, workout) => {


    const workoutsDb = db.collection('workout');
    const exerciseDb = db.collection('exercise');

    let itemWorkout = {
        ...workout,
        type: workout.type.split(','),
        image: `https://firebasestorage.googleapis.com/v0/b/reabita-eda32.appspot.com/o/gifs%2F${workout.exercises[0].thumb}.gif?alt=media`,
        exercises: undefined,
    }

    itemWorkout = await workoutsDb.add(itemWorkout);
    const id = itemWorkout.id;
    console.log(id);

    const exercises = workout.exercises.map((exercise) => ({
        ...exercise,
        workout: undefined,
        thumb: `https://firebasestorage.googleapis.com/v0/b/reabita-eda32.appspot.com/o/gifs%2F${exercise.thumb}.gif?alt=media`,
        idWorkout: db.doc(`workout/${id}`),
    }))

    console.log(exercises);

    for (let j = 0; j < exercises.length; j++) {
        await exerciseDb.add(exercises[j]);
    }
    console.log(itemWorkout);


}

(async () => {

    await readFiles();

    // firebase.initializeApp({
    //     credential: firebase.credential.cert(serviceAccount)
    // });
    //
    // const db = firebase.firestore();
    //
    // const usersDb = db.collection('users');


})()