package com.example.reabita

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
